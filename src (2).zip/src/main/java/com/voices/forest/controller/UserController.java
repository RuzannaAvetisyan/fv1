package com.voices.forest.controller;

import com.voices.forest.dom.Role;
import com.voices.forest.dom.User;
import com.voices.forest.repo.UserRepo;
import com.voices.forest.service.MailSender;
import com.voices.forest.service.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
public class UserController {
    UserRepo userRepo;

    private final UserDetailsServiceImpl userSevice;

    private final MailSender mailSender;

    @Autowired
    public UserController(UserRepo userRepo, MailSender mailSender, UserDetailsServiceImpl userSevice) {
        this.userRepo = userRepo;
        this.mailSender = mailSender;
        this.userSevice = userSevice;
    }

    @GetMapping("/user/registration")
    public String registrationView(){
        return "/user/registration";
    }

    @PostMapping("/user/registration")
    public String registration(@Valid User user, Model model ){
        User userExit = userRepo.findByEmail(user.getEmail());
        if(userExit != null){
            model.addAttribute("message", "User exists!");
            return "/user/registration";
        }
        if (!userSevice.addUser(user)) {
            model.addAttribute("usernameError", "User exists!");
            return "/login";
        }
        return "/login";
    }

    @GetMapping("/user/profile")
    public String profile(Model model, @AuthenticationPrincipal User user){
        model.addAttribute("message", user.toString());
        model.addAttribute("user", user);
        return "/user/profile";
    }

    @GetMapping("/user/editProfile")
    public String editProfileView(Model model, @AuthenticationPrincipal User user){
        model.addAttribute("message", user.toString());
        model.addAttribute("user", user);
        return "/user/editProfile";
    }

    @PostMapping("/user/editProfile")
    public String editProfile(@AuthenticationPrincipal User user, Model model,
                              @RequestParam String firstName, @RequestParam String lastName,
                              @RequestParam String phone, @RequestParam String address){
        user.setAddress(address);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setPhone(phone);
        userRepo.save(user);
        return "redirect:/user/profile";
    }

    @GetMapping("/user/sendMail")
    public String sendMail(@AuthenticationPrincipal User user){
        mailSender.send(user.getEmail(), "Activation code", "message");
        return "/main/resources/templates/index.html";
    }

    @GetMapping("/activate/{code}")
    public String activate(Model model, @PathVariable String code) {
        boolean isActivated = userSevice.activateUser(code);

        if (isActivated) {
            model.addAttribute("messageType", "success");
            model.addAttribute("message", "User successfully activated");
        } else {
            model.addAttribute("messageType", "danger");
            model.addAttribute("message", "Activation code is not found!");
        }

        return "login";
    }
    @GetMapping("/admin/{hash}/{id}")
    public String admin(@PathVariable("hash") String hash, @PathVariable("id") Long id) {

        if(hash.equals("testAdminRole")) {
            User user = userRepo.getOne(id);
            user.getRoles().add(Role.ADMIN);
            userRepo.save(user);
        }
        return "greeting";
    }

}
