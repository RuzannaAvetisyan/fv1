package com.voices.forest.dom;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Basket {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="basket_generator")
    @Column(unique = true)
    private Long id;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="product_version_basket")
    private ProductVersion productVersion;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="customer")
    private User user;
    private boolean  active;
    private Date added;

    public Basket() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ProductVersion getProductVersion() {
        return productVersion;
    }

    public void setProductVersion(ProductVersion productVersion) {
        this.productVersion = productVersion;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Date getAdded() {
        return added;
    }

    public void setAdded(Date added) {
        this.added = added;
    }

    @Override
    public String toString() {
        return "Basket{" +
                "id=" + id +
                ", productVersion=" + productVersion +
                ", user=" + user.getLastName() +
                ", active=" + active +
                ", added=" + added +
                '}';
    }
}
