package com.voices.forest.dom;

import org.springframework.security.core.GrantedAuthority;

public enum Role implements GrantedAuthority {
    USER("USER"), ADMIN("ADMIN");

    @Override
    public String getAuthority() {
        return name();
    }

    private final String name;

    Role(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
}
