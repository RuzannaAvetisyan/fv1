package com.voices.forest.dom;

public enum Status {
    VIEWED("VIEWED"), DELETED("DELETED"), EXECUTED("EXECUTED"), ADDED("ADDED"), REFUSED("REFUSED"), PAID("PAID");

    private final String name;

    Status(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

}
