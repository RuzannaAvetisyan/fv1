package com.voices.forest.repo;

import com.voices.forest.dom.ProductSubtype;
import com.voices.forest.dom.ProductType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import javax.transaction.Transactional;
import java.util.List;


@EnableJpaRepositories
public interface ProductSubtypeRepo extends JpaRepository<ProductSubtype, Long> {
    List<ProductSubtype> findAll();
    List<ProductSubtype> findAllByProductType(ProductType productType);
    ProductSubtype getAllById(Long id);
    ProductSubtype findByProductTypeAndSubtype(ProductType productType, String subtype);
    @Transactional
    Integer removeProductSubtypeByProductType(ProductType productType);
}
