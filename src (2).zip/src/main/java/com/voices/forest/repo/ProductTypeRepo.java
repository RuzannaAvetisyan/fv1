package com.voices.forest.repo;

import com.voices.forest.dom.ProductType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ProductTypeRepo extends JpaRepository<ProductType, Long> {
    @Override
    ProductType getOne(Long id);

    List<ProductType> findAll();
    ProductType findByTypeName(String typeName);
}
