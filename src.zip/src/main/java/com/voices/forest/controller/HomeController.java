package com.voices.forest.controller;

import com.voices.forest.dom.*;
import com.voices.forest.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Date;

@Controller
public class HomeController {
	final AnimalRepo animalRepo;
	final ProductTypeRepo productTypeRepo;
	final ProductSubtypeRepo productSubtypeRepo;
	final ProductRepo productRepo;
	final ProductVersionRepo productVersionRepo;
	final BasketRepo basketRepo;
	final RequestRepo requestRepo;

	@Autowired
	public HomeController(AnimalRepo animalRepo, ProductTypeRepo productTypeRepo, ProductSubtypeRepo productSubtypeRepo, ProductRepo productRepo, ProductVersionRepo productVersionRepo, BasketRepo basketRepo, RequestRepo requestRepo) {
		this.animalRepo = animalRepo;
		this.productTypeRepo = productTypeRepo;
		this.productSubtypeRepo = productSubtypeRepo;
		this.productRepo = productRepo;
		this.productVersionRepo = productVersionRepo;
		this.basketRepo = basketRepo;
		this.requestRepo = requestRepo;
	}

	@RequestMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("productList", productRepo.findAll());
		return "index";
	}
	@RequestMapping(value = "/product_details/{productId}", method = RequestMethod.GET)
	public String productDetails(Model model, @PathVariable("productId") Long productId){
		model.addAttribute("product", productRepo.getOne(productId));
		model.addAttribute("productVersionList", productVersionRepo.findAllByProduct(productRepo.getOne(productId)));
		return "/product_details";
	}
	@GetMapping("/user/basket")
	public String basket(Model model, @AuthenticationPrincipal User user) {
		model.addAttribute("basket", basketRepo.findAllByActiveTrueAndUserEqualsOrderByAddedDesc(user));
		return "/user/basket";
	}

	@GetMapping("/basket/{id}")
	public String basketAdd(Model model, @AuthenticationPrincipal User user, @PathVariable("id") Long id) {
		ProductVersion productVersion = productVersionRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
		Basket basketExist = basketRepo.findFirstByActiveTrueAndUserEqualsAndProductVersionEquals(user,productVersion);
		if(basketExist == null){
			Basket basket = new Basket();
			basket.setActive(true);
			basket.setAdded(new Date());
			basket.setProductVersion(productVersion);
			basket.setUser(user);
			basketRepo.save(basket);
			model.addAttribute("message", "Product added to the basket");
		}else {
			model.addAttribute("message", "The product was previously added to the basket");
		}
		model.addAttribute("basket", basketRepo.findAllByActiveTrueAndUserEqualsOrderByAddedDesc(user));
		return "redirect:/user/basket";
	}

	@GetMapping("/basket_delete/{id}")
	public String basketDelete(Model model, @AuthenticationPrincipal User user, @PathVariable("id") Long id) {
		Basket basketExist = basketRepo.getById(id);
		if(basketExist != null){
			basketExist.setActive(false);
			basketRepo.save(basketExist);
			model.addAttribute("message", "Product deleted");
		}else {
			model.addAttribute("message", "Product not found");
		}
		model.addAttribute("basket", basketRepo.findAllByActiveTrueAndUserEqualsOrderByAddedDesc(user));
		return "redirect:/user/basket";
	}
    @GetMapping("user/request/{id}")
    public String requestView(Model model, @AuthenticationPrincipal User user, @PathVariable("id") Long id) {
        ProductVersion productVersion = productVersionRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));

        model.addAttribute("productVersion", productVersion);
        return "user/request";
    }

	@PostMapping("user/request/{id}")
	public String request(Model attributes, @AuthenticationPrincipal User user, @PathVariable("id") Long id, @Valid Request request) {
		System.out.println(12);
		ProductVersion productVersion = productVersionRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
		Request requestExist = requestRepo.findFirstByActiveTrueAndUserEqualsAndProductVersionEquals(user, productVersion);
		if(requestExist != null){
			System.out.println(1);
			attributes.addAttribute("message", "You have this product");
			attributes.addAttribute("request", requestExist);
			attributes.addAttribute("url", "/requestAddAnyway/" + id + "/" + request.getQuantity());
		}else{
			System.out.println(2);
			request.setProductVersion(productVersion);
			request.setDateAdded(new Date());
			request.setStatus(Status.ADDED);
			request.setActive(true);
			request.setUser(user);
			requestRepo.save(request);
		}

		return "redirect:/user/my_orders";
	}

	@GetMapping("/user/my_orders")
	public String orders(RedirectAttributes redirectAttributes, @AuthenticationPrincipal User user, Model model) {
		redirectAttributes.addAttribute("message");
		redirectAttributes.addAttribute("url");
		model.addAttribute("request", requestRepo.findAllByActiveTrueAndUserEqualsOrderByDateAddedAsc(user));
		return "/user/my_orders";
	}



}
