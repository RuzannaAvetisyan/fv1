package com.voices.forest.controller;


import com.voices.forest.dom.Product;
import com.voices.forest.dom.ProductSubtype;
import com.voices.forest.dom.ProductVersion;
import com.voices.forest.dom.User;
import com.voices.forest.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

@Controller
@RequestMapping("/settings/product")
public class ProductController {
    @Value("${upload.path}")
    private String uploadPath;
    final AnimalRepo animalRepo;
    final ProductTypeRepo productTypeRepo;
    final ProductSubtypeRepo productSubtypeRepo;
    final ProductRepo productRepo;
    final ProductVersionRepo productVersionRepo;

    @Autowired
    public ProductController(AnimalRepo animalRepo, ProductTypeRepo productTypeRepo, ProductSubtypeRepo productSubtypeRepo, ProductRepo productRepo, ProductVersionRepo productVersionRepo) {
        this.animalRepo = animalRepo;
        this.productTypeRepo = productTypeRepo;
        this.productSubtypeRepo = productSubtypeRepo;
        this.productRepo = productRepo;
        this.productVersionRepo = productVersionRepo;
    }

    @GetMapping("/add")
    public String addProductView(Model model){
        model.addAttribute("message");
        model.addAttribute("animalList", animalRepo.findAll());
        model.addAttribute("productTypeList", productTypeRepo.findAll());
        model.addAttribute("productSubtypeList", productSubtypeRepo.findAll());
        model.addAttribute("productList", productRepo.findAll());
        model.addAttribute("productVersionList", productVersionRepo.findAll());
        model.addAttribute("product", new Product());
        model.addAttribute("productSubtype", new ProductSubtype());
        return "/settings/product/add";
    }
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addProduct(@Valid Product product, @AuthenticationPrincipal User user, @RequestParam(required = false)  MultipartFile file, BindingResult bindingResult , Model model, RedirectAttributes redirectAttributes) throws IOException {
        System.out.println(product);
        Product productExit = productRepo.findByProductNameAndDescription(product.getProductName(), product.getDescription());
        if(productExit != null){
            model.addAttribute("message", "product exists!");
            redirectAttributes.addAttribute("message", "product exists!");
            return "redirect:/settings/product/add";
        }
        if (checkUserAndFile(product, file, user, redirectAttributes)) return "redirect:/login";
        product.setUserCreate(user);
        product.setActive(true);
        product.setDateCreate(new Date());
        System.out.println(product);
        productRepo.save(product);

        model.addAttribute("message", "product added!");
        redirectAttributes.addAttribute("message", "product exists!");
        return "redirect:/settings/product/add";
    }
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public String editProductView(@PathVariable("id") Long id, RedirectAttributes redirectAttributes, Model model){
        Product product = productRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
        model.addAttribute("product", product);
        model.addAttribute("animalList", animalRepo.findAll());
        model.addAttribute("productTypeList", productTypeRepo.findAll());
        model.addAttribute("productSubtypeList", productSubtypeRepo.findAll());
        return "/settings/product/edit";
    }
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.POST)
    public String editProduct(@PathVariable("id") Long id, @Valid Product product, @RequestParam(required = false)  MultipartFile file , @AuthenticationPrincipal User user, BindingResult result, RedirectAttributes redirectAttributes, Model model) throws IOException {
        Date dateCreate = productRepo.getOne(product.getId()).getDateCreate();
        if (checkUserAndFile(product, file, user, redirectAttributes)){
            return "redirect:/login";
        }
        product.setUserUpdate(user);
        product.setDateUpdate(new Date());
        product.setDateCreate(dateCreate);
        productRepo.save(product);
        return "redirect:/settings/product/add";
    }

    @GetMapping("/delete/{id}")
    public String productDelete(@PathVariable("id") Long id, Model model){
        Product product = productRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));

        if(product == null){
            return "redirect:/settings/product/add";
        }
        deletePhotoByUrl(product.getUrl());
        productRepo.delete(product);
        return "redirect:/settings/product/add";

    }
    @GetMapping("/delete_photo/{id}")
    public String productDeletePhoto(@PathVariable("id") Long id, @AuthenticationPrincipal User user, Model model){
        Product product = productRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));

        if (deletePhotoByUrl(product.getUrl())){
            return "redirect:/settings/product/edit/"+ id;
        }
        if(user != null){
            product.setUserUpdate(user);
            product.setDateUpdate(new Date());
        }
        product.setUrl(null);
        productRepo.save(product);
        return "redirect:/settings/product/edit/"+ id;
    }
    @GetMapping("/add_version/{productId}")
    public String addProductVersionView(Model model, @PathVariable("productId") Long productId){
        model.addAttribute("product", productRepo.getOne(productId));
        model.addAttribute("productVersion", productVersionRepo.findAllByProduct(productRepo.getOne(productId)));
        return "/settings/product/add_version";
    }
    @RequestMapping(value = "/add_version/{productId}", method = RequestMethod.POST)
    public String addProductVersion(@Valid ProductVersion productVersion, @PathVariable("productId") Long productId, @RequestParam(required = false)  MultipartFile file, BindingResult bindingResult , Model model, RedirectAttributes redirectAttributes) throws IOException {
        Product product = productRepo.findById(productId).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + productId));
        ProductVersion productVersionExit = productVersionRepo.getByProductAndText(product, productVersion.getText());
        if(productVersionExit != null){
            model.addAttribute("message", "productVersion exists!");
            redirectAttributes.addAttribute("message", "productVersion exists!");
            return "redirect:/settings/product/add_version/" + productId;
        }
        if(file != null  &&  !file.isEmpty() ){
            String filename = makeFileName(file);
            productVersion.setUrl(filename);
        }
        productVersionRepo.save(productVersion);
        model.addAttribute("message", "productVersion added!");
        redirectAttributes.addAttribute("message", "productVersion added!");
        return "redirect:/settings/product/add_version/" + productId;
    }
    @RequestMapping(value = "/edit_version/{productId}/{versionId}", method = RequestMethod.GET)
    public String editProductVersionView(@PathVariable("productId") Long productId, @PathVariable("versionId") Long versionId, RedirectAttributes redirectAttributes, Model model){
        Product product = productRepo.findById(productId).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + productId));
        ProductVersion productVersion = productVersionRepo.findById(versionId).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + versionId));

        model.addAttribute("product", product);
        model.addAttribute("productVersion", productVersion);
        return "/settings/product/edit_version";
    }
    @RequestMapping(value = "/edit_version/{productId}/{versionId}", method = RequestMethod.POST)
    public String editProductVersion(@PathVariable("productId") Long productId, @PathVariable("versionId") Long versionId, @Valid ProductVersion productVersion, @RequestParam(required = false) MultipartFile file, BindingResult result, RedirectAttributes redirectAttributes, Model model) throws IOException {
        if(file != null && !file.isEmpty()){
            productVersion.setUrl(makeFileName(file));
        }
        productVersionRepo.save(productVersion);
        return "redirect:/settings/product/add";
    }
    @GetMapping("/delete_version_photo/{productId}/{versionId}")
    public String productVersionDeletePhoto(@PathVariable("productId") Long productId, @PathVariable("versionId") Long versionId, @AuthenticationPrincipal User user, Model model){
        Product product = productRepo.findById(productId).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + productId));
        ProductVersion productVersion = productVersionRepo.findById(versionId).orElseThrow(() -> new IllegalArgumentException("Invalid product version Id:" + versionId));

        if (deletePhotoByUrl(productVersion.getUrl())){
            return "redirect:/settings/product/edit_version/" + productId +"/" + versionId;
        }
        if(user != null){
            product.setUserUpdate(user);
            product.setDateUpdate(new Date());
        }
        productVersion.setUrl(null);
        productRepo.save(product);
        productVersionRepo.save(productVersion);
        return "redirect:/settings/product/edit_version/" + productId +"/" + versionId;
    }
    @GetMapping("/delete_version/{productId}/{versionId}")
    public String productVersionDelete(@PathVariable("productId") Long productId, @PathVariable("versionId") Long versionId, @AuthenticationPrincipal User user, Model model){
        Product product = productRepo.findById(productId).orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + productId));
        ProductVersion productVersion = productVersionRepo.findById(versionId).orElseThrow(() -> new IllegalArgumentException("Invalid product version Id:" + versionId));

        if(product == null || productVersion == null){
            return "redirect:/settings/product/add";
        }
        deletePhotoByUrl(productVersion.getUrl());
        productVersionRepo.delete(productVersion);
        return "redirect:/settings/product/add_version/"+ productId;
    }

    private boolean deletePhotoByUrl(String url) {
        if(url == null){
            return true;
        }
        try{
            File file = new File(uploadPath+"/"+url);
            boolean delete = file.delete();
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }

    private boolean checkUserAndFile(Product product, MultipartFile file, User user, RedirectAttributes redirectAttributes) throws IOException {
        if(user == null){
            redirectAttributes.addAttribute("message", "authorization required");
            return true;
        }
        if(file != null  &&  !file.isEmpty() ){
            String filename = makeFileName(file);
            product.setUrl(filename);
        }
        return false;
    }

    private String makeFileName(MultipartFile file) throws IOException {
        File uploadDir = new File(uploadPath);
        if(!uploadDir.exists()){
            boolean mkdir = uploadDir.mkdir();
        }
        String s = LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY-MM-dd_HH-MM-SS"));
        String uuId = UUID.randomUUID().toString();
        String filename = s + "_" + file.getOriginalFilename();
        file.transferTo(new File(uploadPath + "/" + filename));
        return filename;
    }
}
