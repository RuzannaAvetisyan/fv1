package com.voices.forest.controller;

import com.voices.forest.dom.Animal;
import com.voices.forest.dom.ProductSubtype;
import com.voices.forest.dom.ProductType;
import com.voices.forest.repo.AnimalRepo;
import com.voices.forest.repo.ProductSubtypeRepo;
import com.voices.forest.repo.ProductTypeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/settings")
public class SettingsController {

    final AnimalRepo animalRepo;
    final ProductTypeRepo productTypeRepo;
    final ProductSubtypeRepo productSubtypeRepo;

    @Autowired
    public SettingsController(AnimalRepo animalRepo, ProductTypeRepo productTypeRepo, ProductSubtypeRepo productSubtypeRepo) {
        this.animalRepo = animalRepo;
        this.productTypeRepo = productTypeRepo;
        this.productSubtypeRepo = productSubtypeRepo;
    }

    @RequestMapping(value = "/product_settings", method = RequestMethod.GET)
    public String productSettingsView(){
        return "/settings/product_settings";
    }

    @GetMapping("/add_animal")
    public String animalAddView(Model model){
        model.addAttribute("animals", animalRepo.findAll());
        return "/settings/add_animal";
    }
    @PostMapping("/add_animal")
    public String animalAdd(@Valid Animal animal, Model model){
        Animal animalExit = animalRepo.findByAnimalName(animal.getAnimalName());
        if(animalExit != null){
            model.addAttribute("animals", animalRepo.findAll());
            model.addAttribute("message", "Animal exists!");
            return "/settings/add_animal";
        }
        animalRepo.save(animal);
        model.addAttribute("animals", animalRepo.findAll());
        model.addAttribute("message", "Animal added!");
        return "/settings/add_animal";
    }
    @GetMapping("/edit_animal/{id}")
    public String animalEditView(@PathVariable("id") Long id, Model model){
        Animal animal = animalRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid animal Id:" + id));
        model.addAttribute("animal", animal);
        return "/settings/edit_animal";
    }
    @PostMapping("/edit_animal/{id}")
    public String animalEdit(@PathVariable("id") Long id, @Valid Animal animal, BindingResult result, Model model){
        System.out.println(result);
        if(result.hasFieldErrors()){
            return "/settings/add_animal";
        }
        animalRepo.save(animal);
        return "redirect:/settings/add_animal";
    }
    @GetMapping("/delete_animal/{id}")
    public String animalDelete(@PathVariable("id") Long id, RedirectAttributes attributes){
        Animal animal = animalRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid animal Id:" + id));
        if(animal == null){
            return "redirect:/settings/add_animal";
        }
        try {
            animalRepo.deleteById(id);
        }catch (DataIntegrityViolationException e){
            attributes.addFlashAttribute("message", "first you need to remove all related products");
            return "redirect:/settings/add_animal";
        }
        return "redirect:/settings/add_animal";
    }

    @GetMapping("/add_product_type")
    public String productTypeView(Model model){
        model.addAttribute("message");
        model.addAttribute("types", productTypeRepo.findAll());
        return "/settings/add_product_type";
    }
    @PostMapping("/add_product_type")
    public String productTypeAdd(@Valid ProductType productType, Model model){
        ProductType productTypeExit = productTypeRepo.findByTypeName(productType.getTypeName());
        if(productTypeExit != null){
            model.addAttribute("message", "ProductType exists!");
            return "/settings/add_product_type";
        }
        productTypeRepo.save(productType);
        model.addAttribute("message", "ProductType added!");
        return "/settings/add_product_type";
    }
    @GetMapping("/edit_product_type/{id}")
    public String productTypeEditView(@PathVariable("id") Long id, Model model){
        ProductType productType = productTypeRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product type Id:" + id));
        model.addAttribute("productType", productType);
        return "/settings/edit_product_type";
    }
    @PostMapping("/edit_product_type/{id}")
    public String productTypeEdit(@PathVariable("id") Long id, @Valid ProductType productType, BindingResult result, Model model){
        if(result.hasFieldErrors()){
            return "/settings/add_product_type";
        }
        ProductType productTypeEx = productTypeRepo.getOne(id);
        productTypeEx.setTypeName(productType.getTypeName());
        productTypeRepo.save(productTypeEx);

        return "redirect:/settings/add_product_type";
    }
    @GetMapping("/delete_product_type/{id}")
    public String productTypeDelete(@PathVariable("id") Long id, RedirectAttributes attributes){
        ProductType productType = productTypeRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product type Id:" + id));
        if(productType == null){
            return "/settings/edit_product_type";
        }
        try {
            productTypeRepo.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            attributes.addFlashAttribute("message", "first you need to remove all related products");
            return "redirect:/settings/add_product_type";
        }
        return "redirect:/settings/add_product_type";

    }

    @GetMapping("/add_product_subtype")
    public String productSubtypeView(Model model){
        model.addAttribute("productTypes", productTypeRepo.findAll());
        model.addAttribute("productType", new ProductType());
        model.addAttribute("productSubtype", new ProductSubtype());
        model.addAttribute("productSubtypes", productSubtypeRepo.findAll());
        return "/settings/add_product_subtype";
    }
    @RequestMapping(value = "/add_product_subtype", method = RequestMethod.POST)
    public String productSubtypeAdd(@Valid ProductSubtype productSubtype, BindingResult bindingResult , Model model){
        ProductSubtype productSubtypeExit = productSubtypeRepo.findByProductTypeAndSubtype(productSubtype.getProductType(),productSubtype.getSubtype());
        if(productSubtypeExit != null){
            model.addAttribute("message", "productSubtype exists!");
            model.addAttribute("productTypes", productTypeRepo.findAll());
            model.addAttribute("productType", new ProductType());
            model.addAttribute("productSubtype", new ProductSubtype());
            return "/settings/add_product_subtype";
        }
        if(productSubtype.getProductType() == null || productSubtype.getSubtype() == null){
            model.addAttribute("message", "Something went wrong!");
            model.addAttribute("productTypes", productTypeRepo.findAll());
            model.addAttribute("productType", new ProductType());
            model.addAttribute("productSubtype", new ProductSubtype());
            return "/settings/add_product_subtype";
        }
        productSubtypeRepo.save(productSubtype);
        productSubtype.getProductType().getSubtypes().add(productSubtype);
        productTypeRepo.save(productSubtype.getProductType());
        model.addAttribute("message", "productSubtype added!");
        return "settings/add_product_subtype";
    }
    @GetMapping("/edit_product_subtype/{id}")
    public String productSubtypeEditView(@PathVariable("id") Long id, Model model){
        ProductSubtype productSubtype = productSubtypeRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product subtype Id:" + id));
        model.addAttribute("productSubtype", productSubtype);
        return "/settings/edit_product_subtype";
    }
    @PostMapping("/edit_product_subtype/{id}")
    public String productSubtypeEdit(@PathVariable("id") Long id, @Valid ProductSubtype productSubtype, BindingResult result, Model model){
        System.out.println(productSubtype.toString());
        if(result.hasFieldErrors()){
            return "/settings/add_product_subtype";
        }
        productSubtypeRepo.save(productSubtype);
        return "/settings/add_product_subtype";
    }
    @GetMapping("/delete_product_subtype/{id}")
    public String productSubtypeDelete(@PathVariable("id") Long id, RedirectAttributes attributes){
        ProductSubtype productSubtype = productSubtypeRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product subtype Id:" + id));

        if(productSubtype == null){
            return "/settings/add_product_subtype";
        }
        ProductType cope = productSubtype.getProductType();
        productSubtype.getProductType().getSubtypes().remove(productSubtype);
        productTypeRepo.save(productSubtype.getProductType());
        productSubtype.setProductType(null);
        try {
            productSubtypeRepo.delete(productSubtype);
        }  catch (DataIntegrityViolationException e) {
            cope.getSubtypes().add(productSubtype);
            productSubtype.setProductType(cope);
            productTypeRepo.save(cope);
            attributes.addFlashAttribute("message", "first you need to remove all related products");
            return "redirect:/settings/add_product_subtype";
        }

        return "redirect:/settings/add_product_subtype";

    }
}
