package com.voices.forest.dom;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(unique = true)
    private Long id;
    private String productName;
    private String url;
    private String description;
    private String price;
    private boolean active;
    private boolean inStock;
    private Date dateCreate;
    private Date dateUpdate;
    @ManyToOne (fetch = FetchType.LAZY)
    private User userCreate;
    @ManyToOne(fetch = FetchType.LAZY)
    private User userUpdate;
    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    private ProductSubtype productSubtype;
    @ManyToMany(cascade = CascadeType.REFRESH)
    private List<Animal> animals;
    @OneToMany(cascade = CascadeType.ALL)
    private List<ProductVersion> productVersions;

    public Product() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isInStock() {
        return inStock;
    }

    public void setInStock(boolean inStock) {
        this.inStock = inStock;
    }

    public Date getDateCreate() {
        return dateCreate;
    }

    public void setDateCreate(Date dateCreate) {
        this.dateCreate = dateCreate;
    }

    public Date getDateUpdate() {
        return dateUpdate;
    }

    public void setDateUpdate(Date dateUpdate) {
        this.dateUpdate = dateUpdate;
    }

    public User getUserCreate() {
        return userCreate;
    }

    public void setUserCreate(User userCreate) {
        this.userCreate = userCreate;
    }

    public User getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(User userUpdate) {
        this.userUpdate = userUpdate;
    }

    public ProductSubtype getProductSubtype() {
        return productSubtype;
    }

    public void setProductSubtype(ProductSubtype productSubtype) {
        this.productSubtype = productSubtype;
    }

    public List<Animal> getAnimals() {
        return animals;
    }

    public void setAnimals(List<Animal> animals) {
        this.animals = animals;
    }

    public List<ProductVersion> getProductVersions() {
        return productVersions;
    }

    public void setProductVersions(List<ProductVersion> productVersions) {
        this.productVersions = productVersions;
    }

    @Override
    public String  toString() {
        return "Product{" +
                "id=" + id +
                ", productName='" + productName + '\'' +
                ", url='" + url + '\'' +
                ", description='" + description + '\'' +
                ", price='" + price + '\'' +
                ", active=" + active +
                ", inStock=" + inStock +
                ", dateCreate=" + dateCreate +
                ", dateUpdate=" + dateUpdate +
                ", userCreate=" + userCreate +
                ", userUpdate=" + userUpdate +
                ", productSubtype=" + productSubtype +
                ", animals=" + animals +
                ", productVersions=" + productVersions +
                '}';
    }
}
