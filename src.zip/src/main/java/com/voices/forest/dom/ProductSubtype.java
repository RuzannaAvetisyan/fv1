package com.voices.forest.dom;

import javax.persistence.*;

@Entity
public class ProductSubtype {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    private String subtype;
    @ManyToOne(fetch = FetchType.EAGER)
    private ProductType productType;

    public ProductSubtype(String subtype, ProductType productType) {
        this.subtype = subtype;
        this.productType = productType;
    }

    public ProductSubtype() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype;
    }

    public ProductType getProductType() {
        return productType;
    }

    public void setProductType(ProductType productType) {
        this.productType = productType;
    }

    @Override
    public String toString() {
        return "ProductSubtype{" +
                "id=" + id +
                ", subtype='" + subtype + '\'' +
                ", productType=" + productType +
                '}';
    }
    public String toString2() {
        return  productType.getTypeName() + '\'' + subtype;
    }
}
