package com.voices.forest.dom;


import javax.persistence.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;


@Entity
public class ProductType {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    @Column(unique=true, name="type_name", nullable = false)
    private String typeName;
    @OneToMany(fetch = FetchType.EAGER, orphanRemoval = true, cascade = {CascadeType.REMOVE, CascadeType.REFRESH})
    private List<ProductSubtype> subtypes = new ArrayList<>();

    public ProductType() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public List<ProductSubtype> getSubtypes() {
        return subtypes;
    }

    public void setSubtypes(List<ProductSubtype> subtypes) {
        this.subtypes = subtypes;
    }

    @Override
    public String toString() {
        return "ProductType{" +
                "id=" + id +
                ", typeName='" + typeName + '\'' +
                ", subtypes=" + subtypes.size() +
                '}';
    }
}
