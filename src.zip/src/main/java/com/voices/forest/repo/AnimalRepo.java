package com.voices.forest.repo;

import com.voices.forest.dom.Animal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface AnimalRepo extends JpaRepository<Animal, Long> {
    List<Animal> findAll();
    Animal findByAnimalName(String animalName);
}
