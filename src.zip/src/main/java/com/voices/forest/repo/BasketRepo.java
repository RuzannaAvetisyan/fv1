package com.voices.forest.repo;

import com.voices.forest.dom.Basket;
import com.voices.forest.dom.ProductVersion;
import com.voices.forest.dom.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BasketRepo extends JpaRepository<Basket, Long> {
    List<Basket> findAllBy();
    Basket getById(Long id);
    List<Basket> findAllByActiveTrueAndUserEqualsOrderByAddedDesc(User user);
    List<Basket> findAllByActiveAndUserEqualsOrderByAddedAsc(boolean active, User user);
    List<Basket> findAllByActiveTrueOrderByAddedAsc();
    Basket findFirstByActiveTrueAndUserEqualsAndProductVersionEquals(User user, ProductVersion productVersion);
}
