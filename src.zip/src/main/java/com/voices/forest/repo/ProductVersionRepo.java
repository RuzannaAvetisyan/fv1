package com.voices.forest.repo;

import com.voices.forest.dom.Product;
import com.voices.forest.dom.ProductVersion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
@EnableJpaRepositories
public interface ProductVersionRepo extends JpaRepository<ProductVersion, Long> {
    List<ProductVersion> findAll();
    List<ProductVersion> findAllByProduct(Product product);
    ProductVersion getById(Long id);
    ProductVersion getByProductAndText(Product product, String text);
}
