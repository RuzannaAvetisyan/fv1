package com.voices.forest.repo;

import com.voices.forest.dom.ProductVersion;
import com.voices.forest.dom.Request;
import com.voices.forest.dom.Status;
import com.voices.forest.dom.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Set;

public interface RequestRepo extends JpaRepository<Request, Long> {
    List<Request> findAllBy();
    Request getById(Long id);
    List<Request> findAllByStatusAndUserEqualsOrderByDateAddedAsc(Status status, User user);
    List<Request> findAllByStatusNotContainsAndUserEqualsOrderByDateAddedAsc(Status status, User user);
    List<Request> findAllByStatusInOrderByDateAddedAsc(Set<Status> statuses);
    List<Request> findAllByActiveTrueAndUserEqualsOrderByDateAddedAsc(User user);
    Request findFirstByActiveTrueAndUserEqualsAndProductVersionEquals(User user, ProductVersion productVersion);
}
