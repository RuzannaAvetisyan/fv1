package com.voices.forest.repo;

import com.voices.forest.dom.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface UserRepo extends JpaRepository<User, Long> {
    User findByEmail(String email);

    List<User> findAll();

    User findByActivationCode(String code);
}
