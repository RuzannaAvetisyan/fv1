// $(document).ready(function(){
//     $("#s1").click(function(){
//         alert('Data !!!!!!!.');
//     });
// })
$(document).on("click",".detail-qty .qty-up",function(){
    var min = $(this).prev().attr("min");
    var max = $(this).prev().attr("max");
    var step = $(this).prev().attr("step");
    if(step === undefined) step = 1;
    if(max !==undefined && Number($(this).prev().val())< Number(max) || max === undefined || max === ''){
        if(step!='') $(this).prev().val(Number($(this).prev().val())+Number(step));
    }
    $( 'div.woocommerce > form .button[name="update_cart"]' ).prop( 'disabled', false );
    return false;
})
$(document).on("click",".detail-qty .qty-down",function(){
    var min = $(this).next().attr("min");
    var max = $(this).next().attr("max");
    var step = $(this).next().attr("step");
    if(step === undefined) step = 1;
    if(Number($(this).next().val()) > Number(min)){
        if(min !==undefined && $(this).next().val()>min || min === undefined || min === ''){
            if(step!='') $(this).next().val(Number($(this).next().val())-Number(step));
        }
    }
    $( 'div.woocommerce > form .button[name="update_cart"]' ).prop( 'disabled', false );
    return false;
})
$(document).on("keyup change","input.qty-val",function(){
    $( 'div.woocommerce > form .button[name="update_cart"]' ).prop( 'disabled', false );
})